let todos = JSON.parse(localStorage.getItem("todos")) || [];

const list = document.getElementById('todo-list');
const itemCountSpan = document.getElementById('item-count');
const uncheckedCountSpan = document.getElementById('unchecked-count');

function saveTodos() {
    localStorage.setItem("todos", JSON.stringify(todos));
}

function newTodo() {

    const text = prompt("Введіть нову справу");

    if (!text || text.trim() === "") return;

    const todo = {
        id: Date.now(),
        text: text,
        completed: false
    };

    todos.push(todo);

    saveTodos();
    render(todos);
    updateCounter();
}

function renderTodo(todo) {

    return `
        <li>

            <div class="todo-content">

                <input
                    type="checkbox"
                    ${todo.completed ? "checked" : ""}
                    onchange="checkTodo(${todo.id})"
                >

                <label style="text-decoration:${todo.completed ? "line-through" : "none"};">
                    ${todo.text}
                </label>

            </div>

            <button onclick="deleteTodo(${todo.id})">
                Видалити
            </button>

        </li>
    `;
}

function render(todos) {

    const html = todos.map(todo => renderTodo(todo)).join("");

    list.innerHTML = html;
}

function updateCounter() {

    itemCountSpan.textContent = todos.length;

    const uncompleted = todos.filter(todo => !todo.completed);

    uncheckedCountSpan.textContent = uncompleted.length;
}

function deleteTodo(id) {

    todos = todos.filter(todo => todo.id !== id);

    saveTodos();
    render(todos);
    updateCounter();
}

function checkTodo(id) {

    todos = todos.map(todo => {

        if (todo.id === id) {
            todo.completed = !todo.completed;
        }

        return todo;
    });

    saveTodos();
    render(todos);
    updateCounter();
}

render(todos);
updateCounter();